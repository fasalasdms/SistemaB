import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ApiService } from 'app/services/api.service';
import { PosService } from 'app/services/pos.service';
import { map } from 'rxjs/operators';

export interface dataElement {
  item: number;
  codigo: number;
  producto: string;
  precio: number;
  cantidad: number;
  iva: number;
  descuento: number;
  total: number;
}

const data: dataElement[] = [
  { codigo: 1, item: 1,   producto: 'TENA BASIC 9 UNIDADES',    precio: 40000, cantidad: 2, descuento: 0, iva: 19, total: 80000 },
  { codigo: 2, item: 2,   producto: 'AK.1 DETERGENTE 3900G',    precio: 30900, cantidad: 1, descuento: 0, iva: 0, total: 30900 },
  { codigo: 3, item: 3 ,  producto: 'NATU MALTA 1 LITRO',       precio: 3000,  cantidad: 1, descuento: 0, iva: 19, total: 3000 },
  { codigo: 4, item: 4 ,  producto: 'SIX PACK CERVEZA CORONA',  precio: 18000, cantidad: 3, descuento: 0, iva: 19, total: 54000 },
];

@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.component.html',
  styleUrls: ['./inicio.component.scss']
})
export class InicioComponent implements OnInit {
  dataSource = data;
  dataLength = this.dataSource.length;

  pedidoForm = this._formBuilder.group({
    idBodega     : [, [Validators.required]],
    idCliente     : [, [Validators.required]],
    idTipoPedido     : [, [Validators.required]],
    idFormaPago     : [, [Validators.required]],
    idContacto     : [, [Validators.required]],
    subTotal     : [, [Validators.required]],
    descuento     : [, [Validators.required]],
    iva     : [, [Validators.required]],
    total     : [, [Validators.required]],
    notas     : [, [Validators.required]],
    notasInternas     : [, [Validators.required]],
    ipoComsumo     : [, [Validators.required]],
  });
  dataBodegas: any;
  dataClientes: any;

  constructor(private _formBuilder: FormBuilder, private PostService: PosService, private _apiService: ApiService) { }

  
  getBodegas(){
    this._apiService.getQuery("apiUrlBodegas","bodega",``).subscribe(async(res:any)=>{
      await console.log("Bodegas >", res);
      this.dataBodegas=await res.result;
    });
  }

  getClientes(){
    this._apiService.getQuery("apiUrlClientes","cliente",``).subscribe(async(res:any)=>{
      await console.log("Cliente >", res);
      this.dataClientes=await res;
    });
  }

  getTipoFactura(){
    this._apiService.getQuery("apiUrlClientes","factura/tipoFactura",``).subscribe(async(res:any)=>{
      await console.log("Cliente >", res);
      this.dataClientes=await res;
    });
  }

  ngOnInit(): void {
    this.getBodegas();
    this.getClientes();
  }

}