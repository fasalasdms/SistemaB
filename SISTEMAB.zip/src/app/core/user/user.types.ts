export interface User
{
    id?: string;
    name?: string;
    email?: string;
    avatar?: string;
    status?: string;
    usuario?: string;
    nombreCompleto?:string;
    imagen?:string;
    cargo?:string;
}
