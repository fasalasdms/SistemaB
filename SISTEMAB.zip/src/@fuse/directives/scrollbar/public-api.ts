export * from '@fuse/directives/scrollbar/scrollbar.directive';
export * from '@fuse/directives/scrollbar/scrollbar.module';
