export const environment = {
    production: true,
    apiUrl:"http://192.168.0.104:8082"
};
